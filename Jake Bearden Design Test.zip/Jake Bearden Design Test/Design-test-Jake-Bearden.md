## Design Test Questions

1. How long did you spend on the test? Would you do anything differently if you had more time?
    
    I spent around two hours with the concept. If I had more time I would have liked to explore the dynamic form idea I sketched out. (Sketch-5.jpg/Sketch-6.jpg) It would prevent easily changing inputs, but does streamline the process and save a bit of space. 
    
    I would have also liked to show the reaction of the example images and the estimate showing upon the selection of choices. 

2. Describe what you see as the biggest change you made to improve usability of this design. 

    Trading out the radial buttons for the flat buttons make it easier for the user to select  on mobile/tablets and desktop. 
    
3. Would you be able to code a prototype of this design using HTML and CSS?
    
    Yes.

4. What typeface best describes your personality?

        <!--I apologize, but I could not help but put this in here -->
        Comic Sans. Because I make terribly corny jokes. 

        I would like to say Futura. Because im bold, timeless, and enjoy Nike. 
    
        In actuality I am more of a Montserrat. A clean, workhorse typeface for those that cannot afford gotham.  
